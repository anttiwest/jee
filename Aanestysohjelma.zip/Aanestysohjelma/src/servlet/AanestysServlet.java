package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;



@WebServlet("/nayta_kysymys")
public class AanestysServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public AanestysServlet() {
        super();
    
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Dao dao = new Dao();
		
		if (request.getParameter("kyllaBtn")!=null){
			System.out.println("KYLL�!");
			dao.LisaaVastausKylla();
		}else if (request.getParameter("eiBtn")!=null){
			System.out.println("EI!");
			dao.LisaaVastausEi();
		}else{
			System.out.println("EI KUMPIKAAN");
		}
		
		int kyllaLkm=dao.HaeVastausKylla();
		int eiLkm=dao.HaeVastausEi();
		
		String kyllaStr=""+kyllaLkm;
		String eiStr=""+eiLkm;
		
		request.setAttribute("kyllaStr", kyllaStr);
		request.setAttribute("eiStr", eiStr);
		request.getRequestDispatcher("tulokset.jsp").forward(request, response);
		
		if(request.getParameter("palaaBtn")!=null){
			
		}

		
	}

}

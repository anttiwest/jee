package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



public class Dao {
	
	private Connection yhdista() throws SQLException  , Exception {
    	Connection tietokantayhteys = null;
    	        	
    	String JDBCAjuri = "org.mariadb.jdbc.Driver";
    	String url = "jdbc:mariadb://localhost:15001/a1503902";
        	
    	
    	try {
	         Class.forName(JDBCAjuri);
	        	    	 
	         
	         tietokantayhteys = DriverManager.getConnection(url,"a1503902", "dyMU6p65b");
	
	        
	     }catch (SQLException sqlE){
	         System.err.println("Tietokantayhteyden avaaminen ei onnistunut. " +
	        		 url + "\n" +sqlE.getMessage() + " " + 
	        		 	sqlE.toString()+"\n");
	     				sqlE.printStackTrace();
	         throw( sqlE);
	     }catch (Exception e){
	         System.err.println("TIETOKANTALIITYNN�N VIRHETILANNE: " +
	            "JDBC:n omaa tietokanta-ajuria ei loydy.\n\n" + e.getMessage() +
	            		" " + e.toString() + "\n");
	        			e.printStackTrace();
	         System.out.print("\n");
	         throw (e);
	     }
	     return tietokantayhteys;
	}
	
	public void LisaaVastausKylla(){
		String sql="UPDATE aanestys SET kylla=kylla+1";
		Connection conn=null;
		try {
			conn=yhdista();
			PreparedStatement stmtPrep=conn.prepareStatement(sql);
			stmtPrep.executeUpdate();
			System.out.println("Vastaus tallennettu");
			conn.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void LisaaVastausEi(){
		String sql="UPDATE aanestys SET ei=ei+1";
		Connection conn=null;
		try {
			conn=yhdista();
			PreparedStatement stmtPrep=conn.prepareStatement(sql);
			stmtPrep.executeUpdate();
			System.out.println("Vastaus tallennettu");
			conn.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	public int HaeVastausKylla(){
		int kyllaLkm=0;
		String sql="SELECT kylla FROM aanestys";
		Connection conn=null;
		ResultSet rs=null;
		try {
			conn=yhdista();
			PreparedStatement ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			conn.close();
			if(rs.next()){
			kyllaLkm=rs.getInt("kylla");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Kyll� lkm: "+kyllaLkm);
		return kyllaLkm;
	}
	
	public int HaeVastausEi(){
		int eiLkm=0;
		String sql="SELECT ei FROM aanestys";
		Connection conn=null;
		ResultSet rs=null;
		try {
			conn=yhdista();
			PreparedStatement ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			conn.close();
			if(rs.next()){
				eiLkm=rs.getInt("ei");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return eiLkm;
	}
	
	
}
